module.exports = {
  plugins: [
    require('autoprefixer')({browsers:'ios >= 8'})
  ]
}