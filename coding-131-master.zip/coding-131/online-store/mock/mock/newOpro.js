module.exports = 
    {
        mainImg:{
            img:'http://sx.youxueshop.com/data/afficheimg/1460440788951670189.jpg',
            id:'45',
            title:'这里是新品主题'
        },
        list:[
            {
                id:'123',
                img:'http://sx.youxueshop.com/images/201512/thumb_img/1_thumb_G_1449024889033.jpg',
                title:'新鲜水果甜蜜香脆单果约800克',
                decoration:'食用百香果可以增加胃部饱腹感，减少余热量的摄入，还可以吸附胆固醇和胆汁之类有机分子，抑制人体对脂肪的吸收。因此，长期食用有利于改善人体营养吸收结构，降低体内脂肪，塑造健康优美体态。',
                price:'156',
                oldPrce:'232',
                sales:'506'
            },
            {
                id:'123',
                img:'http://sx.youxueshop.com/images/201511/thumb_img/49_thumb_G_1448162819357.jpg',
                title:'新鲜水果甜蜜香脆单果约800克',
                decoration:'食用百香果可以增加胃部饱腹感，减少余热量的摄入，还可以吸附胆固醇和胆汁之类有机分子，抑制人体对脂肪的吸收。因此，长期食用有利于改善人体营养吸收结构，降低体内脂肪，塑造健康优美体态。',
                price:'156',
                oldPrce:'232',
                sales:'506'
            }
        ]
    }



