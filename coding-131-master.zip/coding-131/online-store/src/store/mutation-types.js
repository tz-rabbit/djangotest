// 使用常量替代mutation事件类型。
export const SET_INFO = 'SET_INFO';
export const SET_NAV = 'SET_NAV';
// export const GET_NAV = 'GET_NAV';

// 获取购物车数据
export const SET_SHOPLIST = 'SET_SHOPLIST';
