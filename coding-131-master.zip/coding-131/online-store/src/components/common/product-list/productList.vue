<template>
    <div class="productlist">
        <ul class="cle">
            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=1" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="新鲜水果甜蜜香脆单果约800克" alt="新鲜水果甜蜜香脆单果约800克" src="./images/1_thumb_G_1449024889033.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥156元

            </b> </span> <span class="productname">新鲜水果甜蜜香脆单果约800克</span> <span class="description">食用百香果可以增加胃部饱腹感，减少余热量的摄入，还可以吸附胆固醇和胆汁之类有机分子，抑制人体对脂肪的吸收。因此，长期食用有利于改善人体营养吸收结构，降低体内脂肪，塑造健康优美体态。</span> <span class="price"> 专柜价：￥232元 </span> <span class="salerow"> 销量：<span class="sales">1000</span>件 </span> </a> <a href="javascript:addToCart(1)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=2" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="田然牛肉大黄瓜条生鲜牛肉冷冻真空黄牛" alt="田然牛肉大黄瓜条生鲜牛肉冷冻真空黄牛" src="./images/2_thumb_G_1448945810147.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥88元

            </b> </span> <span class="productname">田然牛肉大黄瓜条生鲜牛肉冷冻真空黄牛</span> <span class="description">前腿+后腿+羊排共8斤，原生态大山放牧羊羔，曾经的皇室贡品，央视推荐，2005年北京招待全球财金首脑。五层专用包装箱+真空包装+冰袋+保鲜箱+顺丰冷链发货，路途保质期8天</span> <span class="price"> 专柜价：￥106元 </span> <span class="salerow"> 销量：<span class="sales">743</span>件 </span> </a> <a href="javascript:addToCart(2)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=7" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="酣畅家庭菲力牛排10片澳洲生鲜牛肉团购套餐" alt="酣畅家庭菲力牛排10片澳洲生鲜牛肉团购套餐" src="./images/7_thumb_G_1448945104346.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥238元

            </b> </span> <span class="productname">酣畅家庭菲力牛排10片澳洲生鲜牛肉团购套餐</span> <span class="description"></span> <span class="price"> 专柜价：￥286元 </span> <span class="salerow"> 销量：<span class="sales">743</span>件 </span> </a> <a href="javascript:addToCart(7)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=47" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="日本蒜蓉粉丝扇贝270克6只装" alt="日本蒜蓉粉丝扇贝270克6只装" src="./images/47_thumb_G_1448946213633.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥108元

            </b> </span> <span class="productname">日本蒜蓉粉丝扇贝270克6只装</span> <span class="description"></span> <span class="price"> 专柜价：￥156元 </span> <span class="salerow"> 销量：<span class="sales">524</span>件 </span> </a> <a href="javascript:addToCart(47)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=10" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="内蒙新鲜牛肉1斤清真生鲜牛肉火锅食材" alt="内蒙新鲜牛肉1斤清真生鲜牛肉火锅食材" src="./images/10_thumb_G_1448944572962.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥88元

            </b> </span> <span class="productname">内蒙新鲜牛肉1斤清真生鲜牛肉火锅食材</span> <span class="description"></span> <span class="price"> 专柜价：￥106元 </span> <span class="salerow"> 销量：<span class="sales">346</span>件 </span> </a> <a href="javascript:addToCart(10)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=4" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="乌拉圭进口牛肉卷 特级肥牛卷" alt="乌拉圭进口牛肉卷 特级肥牛卷" src="./images/4_thumb_G_1448945381841.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥75元

            </b> </span> <span class="productname">乌拉圭进口牛肉卷 特级肥牛卷</span> <span class="description"></span> <span class="price"> 专柜价：￥90元 </span> <span class="salerow"> 销量：<span class="sales">256</span>件 </span> </a> <a href="javascript:addToCart(4)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=8" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="五星眼肉牛排套餐8片装原味原切生鲜牛肉" alt="五星眼肉牛排套餐8片装原味原切生鲜牛肉" src="./images/8_thumb_G_1448945032585.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥125元

            </b> </span> <span class="productname">五星眼肉牛排套餐8片装原味原切生鲜牛肉</span> <span class="description"></span> <span class="price"> 专柜价：￥150元 </span> <span class="salerow"> 销量：<span class="sales">84</span>件 </span> </a> <a href="javascript:addToCart(8)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=11" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="澳洲进口120天谷饲牛仔骨4份原味生鲜" alt="澳洲进口120天谷饲牛仔骨4份原味生鲜" src="./images/11_thumb_G_1448944388914.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥26元

            </b> </span> <span class="productname">澳洲进口120天谷饲牛仔骨4份原味生鲜</span> <span class="description"></span> <span class="price"> 专柜价：￥31元 </span> <span class="salerow"> 销量：<span class="sales">84</span>件 </span> </a> <a href="javascript:addToCart(11)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=6" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="潮香村澳洲进口牛排家庭团购套餐20片" alt="潮香村澳洲进口牛排家庭团购套餐20片" src="./images/6_thumb_G_1448945167914.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥199元

            </b> </span> <span class="productname">潮香村澳洲进口牛排家庭团购套餐20片</span> <span class="description"></span> <span class="price"> 专柜价：￥239元 </span> <span class="salerow"> 销量：<span class="sales">78</span>件 </span> </a> <a href="javascript:addToCart(6)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=9" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="爱食派内蒙古呼伦贝尔冷冻生鲜牛腱子肉1000g" alt="爱食派内蒙古呼伦贝尔冷冻生鲜牛腱子肉1000g" src="./images/9_thumb_G_1448944791708.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥168元

            </b> </span> <span class="productname">爱食派内蒙古呼伦贝尔冷冻生鲜牛腱子肉1000g</span> <span class="description"></span> <span class="price"> 专柜价：￥202元 </span> <span class="salerow"> 销量：<span class="sales">74</span>件 </span> </a> <a href="javascript:addToCart(9)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>



            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=3" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="澳洲进口牛尾巴300g 新鲜肥牛肉" alt="澳洲进口牛尾巴300g 新鲜肥牛肉" src="./images/3_thumb_G_1448945490826.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥255元

            </b> </span> <span class="productname">澳洲进口牛尾巴300g 新鲜肥牛肉</span> <span class="description">新鲜羊羔肉整只共15斤，原生态大山放牧羊羔，曾经的皇室贡品，央视推荐，2005年北京招待全球财金首脑。五层专用包装箱+真空包装+冰袋+保鲜箱+顺丰冷链发货，路途保质期8天</span> <span class="price"> 专柜价：￥306元 </span> <span class="salerow"> 销量：<span class="sales">63</span>件 </span> </a> <a href="javascript:addToCart(3)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>





            <li> <a href="http://sx.web51.youxueshop.com/goods.php?id=3" target="_blank" class="productitem"> <span class="productimg">
                <img width="150" height="150" title="澳洲进口牛尾巴300g 新鲜肥牛肉" alt="澳洲进口牛尾巴300g 新鲜肥牛肉" src="./images/3_thumb_G_1448945490826.jpg" style="display: block;"> </span> <span class="nalaprice xszk"><b>
                ￥255元

            </b> </span> <span class="productname">澳洲进口牛尾巴300g 新鲜肥牛肉</span> <span class="description">新鲜羊羔肉整只共15斤，原生态大山放牧羊羔，曾经的皇室贡品，央视推荐，2005年北京招待全球财金首脑。五层专用包装箱+真空包装+冰袋+保鲜箱+顺丰冷链发货，路途保质期8天</span> <span class="price"> 专柜价：￥306元 </span> <span class="salerow"> 销量：<span class="sales">63</span>件 </span> </a> <a href="javascript:addToCart(3)" class="addcart" target="_blank" rel="nofollow">加入购物车</a> </li>
        </ul>
    <br clear="all">
</div>
</template>
<script>

    export default {
        data () {
            return {
                
            };
        },
        props: {
            
        },
        created () {
            
        },
        watch: {
            
        },
        computed: {

        },
        methods: {
            
        }
    }
</script>
<style scoped>
html {

    color:#333;
    _background-attachment:fixed
}

body,h1,h2,h3,h4,h5,h6,hr,p,blockquote,dl,dt,dd,ul,ol,li,pre,form,fieldset,legend,button,input,select,textarea,th,td {
    margin:0;
    padding:0
}
body,button,input,select,textarea {
    font:12px/1.5 "Microsoft YaHei",Tahoma,Helvetica,Arial,simsun
}
address,cite,dfn,em,var,i {
    font-style:normal
}
ul,ol {
    list-style:none
}
fieldset,img {
    border:0
}
h1 {
    font-size:18px
}
h2 {
    font-size:14px;
    font-weight:bold
}
h3 {
    font-size:14px;
    font-weight:400
}
h4,h5 {
    font-size:12px;
    font-weight:400
}
input,textarea,button,select {
    font-size:12px;
    outline:0;
    resize:none;
    color:#333
}
button {
    cursor:pointer
}
table {
    border-collapse:collapse;
    border-spacing:0
}
.clear {
    clear:both;
    height:0;
    font-size:0;
    line-height:0;
    overflow:hidden
}
.cle:after,.clearfix:after,.clear_f:after,.cle_float:after {
    visibility:hidden;
    display:block;
    font-size:0;
    content:'\20';
    clear:both;
    height:0
}
.cle,.clearfix,.clear_f,.cle_float {
    *zoom:1
}
.fl {
    float:left
}
.fr {
    float:right
}
a {
    text-decoration:none;
    color:#333;
    -webkit-transition:color .2s;
    -moz-transition:color .2s;
    -o-transition:color .2s;
    -ms-transition:color .2s;
    transition:color .2s
}
a:hover {
    color:#09c762
}
a:focus,area:focus {
    outline:0
}
::selection {
    background:#09c762;
    color:#fff
}
canvas {
    -ms-touch-action:double-tap-zoom
}


a.productitem {
    display:block;
+zoom:1;
    cursor:pointer;
    background-color:#fff;
    border:1px solid #eee;
    padding-bottom:8px;
    position:relative;
    overflow:hidden
}
a.productitem span {
    padding:0 10px
}
a.productitem span.productimg {
    display:block;
    /*background:url(images/loading-16.gif) center center no-repeat;*/
    margin-bottom:10px;
    padding:0
}
a.productitem span.productimg img {
    vertical-align:top;
    display:block
}
a.productitem span.nalaprice {
    color:#09c762;
    font-size:14px;
    display:block
}
a.productitem span.productname {
    display:block;
    height:35px;
    line-height:16px;
    overflow:hidden;
    color:#666
}
a.productitem span.description {
    display:block;
    height:16px;
    overflow:hidden;
    color:#999
}
a.productitem span.salerow {
    display:block;
    color:#999
}
a.productitem span.sales {
    color:#09c762;
    padding:0 2px
}
a.productitem span.xszk {
    padding-left:55px;
    /*background:url(images/xsdz-ico.png?0226) 10px center no-repeat*/
}
a.productitem span.price {
    display:none
}
a.productitem:hover {
    text-decoration:none;
    border-color:#09c762
}

.productlist{width:970px;overflow:hidden}
.productlist ul{margin-right:-20px}
.productlist li{width:232px;height:342px;position:relative;float:left;margin:0 14px 14px 0;overflow:hidden;display:inline}
.productlist li a.productitem span.productimg img{width:230px;height:230px}
        
</style>
