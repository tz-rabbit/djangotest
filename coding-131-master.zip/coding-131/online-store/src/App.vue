<template>
    <div id="warp-box">
        <!--这里是全局视图层-->
        <router-view></router-view>
    </div>
</template>
<style>

</style>